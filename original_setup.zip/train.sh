#!/usr/bin/env bash

schedulers="CosineAnnealing" #  MultiStepLR step_cosine StepLR"

echo "===================================================="
echo "Starting training with the following configurations:"
echo "===================================================="

for sch in $schedulers
do
        fname="${sch}"
        echo "============================="
        echo "|> Current Experiment Setup:"
        echo "|> Scheduler=$sch"
        echo "============================="
        
        python train.py \
        --file_name "$fname" \
        --scheduler "$sch"
done

import os
import random
import shutil
from pathlib import Path

def extract_random_image_pairs(hdr_folder, ldr_folder, output_folder, num_samples=200):
    """
    Randomly extract matching HDR and LDR image pairs for testing.
    
    Args:
        hdr_folder (str): Path to folder containing HDR images
        ldr_folder (str): Path to folder containing LDR/JPG images
        output_folder (str): Path to output folder for extracted pairs
        num_samples (int): Number of image pairs to extract (default: 200)
    """
    
    # Create output directories
    output_path = Path(output_folder)
    hdr_output = output_path / "hdr"
    ldr_output = output_path / "ldr"
    
    hdr_output.mkdir(parents=True, exist_ok=True)
    ldr_output.mkdir(parents=True, exist_ok=True)
    
    # Get all HDR files
    hdr_path = Path(hdr_folder)
    hdr_extensions = ['.hdr', '.exr', '.tiff', '.tif']  # Common HDR formats
    hdr_files = []
    
    for ext in hdr_extensions:
        hdr_files.extend(list(hdr_path.glob(f"*{ext}")))
        hdr_files.extend(list(hdr_path.glob(f"*{ext.upper()}")))  # Include uppercase
    
    # Get all LDR files
    ldr_path = Path(ldr_folder)
    ldr_extensions = ['.jpg', '.jpeg', '.png', '.bmp']  # Common LDR formats
    ldr_files = []
    
    for ext in ldr_extensions:
        ldr_files.extend(list(ldr_path.glob(f"*{ext}")))
        ldr_files.extend(list(ldr_path.glob(f"*{ext.upper()}")))  # Include uppercase
    
    # Create dictionaries with normalized filename stems as keys
    hdr_dict = {f.stem.lower(): f for f in hdr_files}  # Convert to lowercase
    ldr_dict = {f.stem.lower(): f for f in ldr_files}  # Convert to lowercase
    
    # Find matching pairs
    matching_pairs = []
    for stem in hdr_dict:
        if stem in ldr_dict:
            matching_pairs.append((hdr_dict[stem], ldr_dict[stem]))
    
    # Print some examples for verification
    print("Sample matching pairs:")
    for i, (hdr_file, ldr_file) in enumerate(matching_pairs[:5]):
        print(f"  {hdr_file.name} <-> {ldr_file.name}")
    
    
    print(f"Found {len(matching_pairs)} matching image pairs")
    
    if len(matching_pairs) == 0:
        print("No matching pairs found. Please check your folder paths and file naming.")
        return
    
    # Randomly sample pairs
    if len(matching_pairs) < num_samples:
        print(f"Warning: Only {len(matching_pairs)} pairs available, extracting all of them.")
        selected_pairs = matching_pairs
    else:
        selected_pairs = random.sample(matching_pairs, num_samples)
    
    print(f"Extracting {len(selected_pairs)} random image pairs...")
    
    # Copy selected pairs
    for i, (hdr_file, ldr_file) in enumerate(selected_pairs):
        try:
            # Copy HDR file
            hdr_dest = hdr_output / hdr_file.name
            shutil.copy2(hdr_file, hdr_dest)
            
            # Copy LDR file
            ldr_dest = ldr_output / ldr_file.name
            shutil.copy2(ldr_file, ldr_dest)
            
            if (i + 1) % 50 == 0:  # Progress update every 50 files
                print(f"Extracted {i + 1}/{len(selected_pairs)} pairs")
                
        except Exception as e:
            print(f"Error copying {hdr_file.stem}: {e}")
    
    print(f"\nExtraction complete!")
    print(f"HDR images saved to: {hdr_output}")
    print(f"LDR images saved to: {ldr_output}")
    
    # Print some statistics
    print(f"\nStatistics:")
    print(f"Total matching pairs found: {len(matching_pairs)}")
    print(f"Pairs extracted: {len(selected_pairs)}")

# Example usage
if __name__ == "__main__":
    # Set your folder paths here
    hdr_folder_path = "/mnt/C23A18653A18592D/Dataset/Dataset/HDR/SingleHDR_training_data/AIM-train/hdr"
    ldr_folder_path = "/mnt/C23A18653A18592D/Dataset/Dataset/HDR/SingleHDR_training_data/AIM-train/jpg"
    output_folder_path = "/mnt/C23A18653A18592D/Dataset/Dataset/HDR/TEST/aim_test_from_train"
    
    # Extract 200 random pairs
    extract_random_image_pairs(
        hdr_folder=hdr_folder_path,
        ldr_folder=ldr_folder_path,
        output_folder=output_folder_path,
        num_samples=200
    )
    
    # Alternative: Extract all matching pairs
    # extract_random_image_pairs(
    #     hdr_folder=hdr_folder_path,
    #     ldr_folder=ldr_folder_path,
    #     output_folder=output_folder_path,
    #     num_samples=len(matching_pairs)  # This would extract all pairs
    # )
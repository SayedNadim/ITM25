# -*- coding: utf-8 -*-

import glob
import math
import os
import random

import cv2
import numpy as np
from torch.utils import data

try:
    import utility
except:
    import sys

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    import utility

random.seed(60)


def read_hdr(path, peak=1000.0):
    hdr = cv2.imread(path, cv2.IMREAD_ANYDEPTH | cv2.IMREAD_UNCHANGED)
    hdr = hdr[:, :, [2, 1, 0]]  # Convert BGR to RGB
    hdr = hdr / peak
    return hdr.astype(np.float32)


def read_ldr(path, gamma=2.2):
    ldr = cv2.imread(path)
    ldr = ldr[:, :, [2, 1, 0]]  # Convert BGR to RGB
    ldr = ldr.astype(np.float32) / 255.0  # normalise to [0, 1]
    # ldr = utility.srgb_to_linear_np(ldr)  # convert sRGB to linear RGB
    return ldr


class AIM(data.Dataset):
    def __init__(self, args, attr="train"):
        self.first = 0
        self.args = args
        self.attr = attr
        self.modulo = 32
        self.real = args.real
        self.args.peak = args.peak if hasattr(args, "peak") else 1000.0
        self.args.gamma = args.gamma if hasattr(args, "gamma") else 2.2

        # Only store the filenames
        print(f"|> Loading {attr} dataset from {args.data_dict[attr]}")
        self.img_list = glob.glob(f"{self.args.data_dict[attr]}" + "/*.jpg")
        if attr == "train":
            np.random.shuffle(self.img_list)
        elif attr == "val":
            self.img_list = sorted(self.img_list)

    def __len__(self):
        return len(self.img_list)

    def __getitem__(self, item):
        item = item % len(self.img_list)

        if self.attr == "train":
            ldr_name = self.img_list[item]
            hdr_name = ldr_name.replace("jpg", "hdr")
            name = os.path.basename(ldr_name).split(".")[0]

            hdr_img = read_hdr(hdr_name, peak=self.args.peak)
            ldr_img = read_ldr(ldr_name, gamma=self.args.gamma)

            hdr_img, ldr_img = utility.mod_crop(
                hdr_img, modulo=self.modulo
            ), utility.mod_crop(ldr_img, modulo=self.modulo)
            hdr_img, ldr_img = utility.get_patch(
                hdr_img, ldr_img, patch_size=self.args.patch_size, scale=1
            )
            if self.args.data_augment:
                hdr_img, ldr_img = utility.augment(hdr_img, ldr_img)
                # hdr_img, ldr_img = utility.LDRHDRAug(crop_size=224)(hdr_img, ldr_img)

            min_value = np.min(hdr_img)
            max_value = np.max(hdr_img)
            hdr_img, ldr_img = utility.np_to_tensor(hdr_img, ldr_img)

        elif self.attr in ["test"]:
            ldr_name = self.img_list[item]
            hdr_name = ldr_name.replace("jpg", "hdr")
            name = os.path.basename(ldr_name).split(".")[0]

            hdr_img = read_hdr(hdr_name, peak=self.args.peak)
            ldr_img = read_ldr(ldr_name, gamma=self.args.gamma)

            min_value = np.min(hdr_img)
            max_value = np.max(hdr_img)

            hdr_img, ldr_img = utility.np_to_tensor(hdr_img, ldr_img)

        elif self.attr in ["aim_val", "aim_test"]:
            ldr_name = self.img_list[item]
            name = os.path.basename(ldr_name).split(".")[0]
            ldr_img = read_ldr(ldr_name, gamma=self.args.gamma)

            min_value = 0
            max_value = 1
            ldr_img = utility.np_to_tensor(ldr_img)[0]
            hdr_img = None
        else:
            raise ValueError(f"|> Unknown attribute: {self.attr}")

        sample = {
            "ldr_img": ldr_img,
            "min_value": min_value,
            "max_value": max_value,
            "name": name,
        }
        if hdr_img is not None:
            sample["hdr_img"] = hdr_img
        return sample


if __name__ == "__main__":
    import argparse

    import yaml
    from easydict import EasyDict as edict

    parser = argparse.ArgumentParser(description="AIM Dataset Loader")
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    parsed = parser.parse_args()

    print(f"Loading configuration from {parsed.config}")

    with open(parsed.config, "r") as f:
        args = yaml.safe_load(f)
        args = edict(args)

    dataset = AIM(args, attr="aim_val")
    print(len(dataset))

    for i in range(len(dataset)):
        sample = dataset[i]
        print(f"Sample {i}:")
        if sample["hdr_img"] is not None:
            print(
                f"  hdr Image shape: {sample['hdr_img'].shape}, Min: {sample['hdr_img'].min()}, Max: {sample['hdr_img'].max()}"
            )
            cv2.imshow(
                "hdr Image",
                (
                    sample["hdr_img"].numpy().transpose(1, 2, 0)[:, :, [2, 1, 0]] * 255.0
                ).astype(np.uint8),
            )
        print(
            f"  ldr Image shape: {sample['ldr_img'].shape}, Min: {sample['ldr_img'].min()}, Max: {sample['ldr_img'].max()}"
        )
        print(f"  Min value: {sample['min_value']}")
        print(f"  Max value: {sample['max_value']}")

        cv2.imshow(
            "ldr Image",
            (
                sample["ldr_img"].numpy().transpose(1, 2, 0)[:, :, [2, 1, 0]] * 255.0
            ).astype(np.uint8),
        )
        cv2.waitKey(0)

        if i == 5:
            break
    cv2.destroyAllWindows()

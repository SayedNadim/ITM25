# -*- coding: utf-8 -*-

from importlib import import_module

from prefetch_generator import BackgroundGenerator
from torch.utils import data as u_data

import data


class DataLoaderX(u_data.DataLoader):

    def __iter__(self):
        return BackgroundGenerator(super().__iter__())


class Data:
    def __init__(self, args, attr):
        self.loader_train = None
        self.data_loader = None
        self.load_npy = True
        self.attr = attr
        if self.attr == "train":
            train_data = getattr(import_module("data.aim"), args.dataset_name)(
                args, attr="train"
            )
            self.loader_train = DataLoaderX(
                dataset=train_data,
                batch_size=args.batch_size,
                shuffle=True,
                num_workers=args.num_workers,
                pin_memory=not args.cpu,
                drop_last=True,
            )
            print(f"|> Length of Train Data: {len(train_data)}")
            print(f"|> Number of Training Batch: {len(self.loader_train)}")

        else:
            data_set = getattr(
                import_module("data." + args.dataset_name.lower()), args.dataset_name
            )(args, attr=attr)
            self.data_loader = DataLoaderX(
                dataset=data_set,
                batch_size=args.test_batch_size if attr == "test" else 1,
                shuffle=False,
                num_workers=0,
                pin_memory=False,
                drop_last=False,
            )
            print(f"|> Length of {str(attr).capitalize()} Data: {len(data_set)}")
            print(
                f"|> Number of {str(attr).capitalize()} Batch: {len(self.data_loader)}"
            )


def get_dataloader(args, attr):
    return Data(args=args, attr=attr)

from torch.optim.lr_scheduler import (CosineAnnealingLR,
                                      CosineAnnealingWarmRestarts, CyclicLR,
                                      LambdaLR, MultiStepLR, OneCycleLR,
                                      ReduceLROnPlateau, SequentialLR, StepLR)


def get_scheduler(optimizer, n_iter_per_epoch, args):
    total_iters = args.num_epochs * n_iter_per_epoch

    if args.scheduler == "StepLR":
        return StepLR(
            optimizer,
            step_size=args.step_size * n_iter_per_epoch,
            gamma=args.lr_decay_rate,
        )

    elif args.scheduler == "MultiStepLR":
        milestones = [m * n_iter_per_epoch for m in args.lr_decay_epochs]
        return MultiStepLR(
            optimizer,
            milestones=milestones,
            gamma=args.lr_decay_rate,
        )

    elif args.scheduler == "CosineAnnealing":
        return CosineAnnealingLR(
            optimizer,
            T_max=total_iters,
            eta_min=args.T_min,
        )

    # --- new: SGDR / warm restarts ---
    elif args.scheduler in ("SGDR", "CosineWarmRestarts"):
        # T_0 = args.restart_epochs * n_iter_per_epoch
        # T_mult = how much to grow the cycle each restart
        return CosineAnnealingWarmRestarts(
            optimizer,
            T_0=args.restart_epochs * n_iter_per_epoch,
            T_mult=args.restart_mult,
            eta_min=args.T_min,
        )

    elif args.scheduler == "CyclicLR":
        return CyclicLR(
            optimizer,
            base_lr=args.base_lr,
            max_lr=args.max_lr,
            step_size_up=args.step_size_up,
            step_size_down=args.step_size_down,
            mode='triangular2',          # e.g. "triangular2"
            cycle_momentum=False,
        )

    elif args.scheduler == "Poly":
        # power defaults to 0.9 if not set
        power = getattr(args, "poly_power", 0.9)
        return LambdaLR(
            optimizer,
            lambda it: (1 - it / total_iters) ** power
        )

    elif args.scheduler == "OneCycleLR":
        return OneCycleLR(
            optimizer,
            max_lr=args.lr,
            total_steps=total_iters,
            pct_start=0.1,
            anneal_strategy="cos",
            div_factor=10,
            final_div_factor=1e4,
        )

    elif args.scheduler == "ReduceLROnPlateau":
        return ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=args.lr_decay_rate,
            patience=args.patience,
            cooldown=args.cooldown,
            verbose=True,
        )

    elif args.scheduler == "step_cosine":
        split_iter = int(args.step_cosine_pct * total_iters)
        step = StepLR(optimizer,
                       step_size=args.step_size * n_iter_per_epoch,
                       gamma=args.lr_decay_rate)
        cosine = CosineAnnealingLR(optimizer,
                                   T_max=total_iters - split_iter,
                                   eta_min=args.T_min)
        return SequentialLR(
            optimizer,
            schedulers=[step, cosine],
            milestones=[split_iter],
        )

    else:
        raise ValueError(f"Unknown scheduler: {args.scheduler}")

# -*- coding: utf-8 -*-
import fnmatch
import os
import time

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torchnet as tnt
import tqdm
from prettytable import PrettyTable
from torch.nn.functional import interpolate

import utility
from data import get_dataloader
from lr_scheduler import get_scheduler


class Trainer:
    def __init__(
        self,
        args,
        my_model,
        my_loss,
        checkpoint_dir="./checkpoints",
        device=None,
        optimizer=None,
        scheduler=None,
        epoch_num=0,
        step=0,
        best_avg_psnr=-1e10,
    ):
        self.args = args
        self.loss = my_loss
        self.model = my_model

        self.start_time = time.time()
        self.epoch_num = epoch_num
        self.step = step
        self.checkpoint_dir = checkpoint_dir
        self.device = (
            torch.device("cpu" if self.args.cpu else "cuda")
            if device is None
            else device
        )
        self.optimizer = (
            utility.make_optimizer(self.args, self.model)
            if optimizer is None
            else optimizer
        )
        self.loader_train = get_dataloader(args=self.args, attr="train").loader_train
        self.scheduler = (
            get_scheduler(
                self.optimizer, n_iter_per_epoch=len(self.loader_train), args=args
            )
            if scheduler is None
            else scheduler
        )
        self.best_avg_psnr = -float("inf") if best_avg_psnr is None else best_avg_psnr

        # Visualization dirs
        self.train_vis_dir = os.path.join(
            "./visualizations", self.args.file_name, "train"
        )
        self.test_vis_dir = os.path.join(
            "./visualizations", self.args.file_name, "test"
        )
        os.makedirs(self.train_vis_dir, exist_ok=True)
        if self.args.save_val_images:
            os.makedirs(self.test_vis_dir, exist_ok=True)

        self.train_meters = {
            "total": tnt.meter.AverageValueMeter(),
            "l1": tnt.meter.AverageValueMeter(),
            "rmse": tnt.meter.AverageValueMeter(),
            "psnr": tnt.meter.AverageValueMeter(),
            "ssim": tnt.meter.AverageValueMeter(),
            "lpips": tnt.meter.AverageValueMeter(),
        }
        self.loss_weight = 1
        self.l1_weight = self.args.l1_weight

    def train(self):
        for epoch_num in range(self.epoch_num, self.args.num_epochs):
            # Visualization & plots
            epoch_dir = os.path.join(self.train_vis_dir, f"epoch_{epoch_num}")
            os.makedirs(epoch_dir, exist_ok=True)

            for m in self.train_meters.values():
                m.reset()

            self.model.train()

            self.epoch_num = epoch_num
            p_bar = tqdm.tqdm(self.loader_train)

            for batch_idx, sample in enumerate(p_bar):
                # if batch_idx >= 10:
                #     break
                self.step += 1
                self.optimizer.zero_grad()
                gt_img, ldr_img, min_val, max_val = (
                    sample["hdr_img"].to(self.device),
                    sample["ldr_img"].to(self.device),
                    sample["min_value"].to(self.device),
                    sample["max_value"].to(self.device),
                )
                out_img = self.model(x=ldr_img)
                # print(f"gt max: {gt_img.max()}, min: {gt_img.min()}")
                # print(f"ldr max: {ldr_img.max()}, min: {ldr_img.min()}")
                # print(f"out max: {out_img[-1].max()}, min: {out_img[-1].min()}")

                loss_dict = self.loss(pred_list=out_img, gt=gt_img, ldr=ldr_img)
                total_loss = loss_dict["loss"] * self.l1_weight
                loss_total = total_loss

                loss_total.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()

                if not isinstance(
                    self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau
                ):
                    self.scheduler.step()

                rmse = utility.root_mean_sqrt_error(out_img[-1], gt_img)
                psnr = utility.batch_psnr(
                    utility.hdr_to_pu(out_img[-1]),
                    utility.hdr_to_pu(gt_img),
                    data_range=1,
                )
                ssim = utility.calculate_ssim(
                    utility.hdr_to_pu(out_img[-1]),
                    utility.hdr_to_pu(gt_img),
                )
                self.train_meters["total"].add(loss_total.item())
                self.train_meters["l1"].add(total_loss.item())
                self.train_meters["rmse"].add(rmse)
                self.train_meters["psnr"].add(psnr)
                self.train_meters["ssim"].add(ssim)
                p_bar.set_description(f"|> Epoch: {self.epoch_num:03d}")
                p_bar.set_postfix(
                    # lr=f"{self.optimizer.param_groups[0]['lr']:.2e}",
                    RMSE=f"{rmse:.4f}",
                    PSNR=f"{psnr:.4f}",
                    SSIM=f"{ssim:.4f}",
                    LOSS=f"{self.train_meters['total'].value()[0]:.7f}",
                )
                if self.step % self.args.train_img_save_freq == 0:
                    prefix = f"train_epoch{epoch_num}_step{self.step}"
                    input_tone = ldr_img  # utility.range_compressor_cuda(ldr_img)
                    gt_tone = utility.range_compressor_cuda(gt_img)
                    out_tone = utility.range_compressor_cuda(out_img[-1])
                    utility.save_visualization(
                        input_tone,
                        out_tone,
                        gt_tone,
                        min_val,
                        max_val,
                        batch_idx,
                        prefix,
                        epoch_dir,
                    )

                # stop and exit if the psnr is less than 0
                if epoch_num > 2 and psnr < 0:
                    print("=" * 50)
                    print(
                        f"|> PSNR is less than 0 at epoch {epoch_num}, step {self.step}. Stopping training."
                    )
                    print("=" * 50)
                    return
            print("=" * 50)
            print(
                f"|> Epoch: {self.epoch_num}: Training Summary\n"
                f"==========================\n"
                f"|| Step: {self.step}|| "
                f"Loss: {self.train_meters['total'].value()[0]:.7f}|| "
                f"RMSE: {self.train_meters['rmse'].value()[0]:.4f}|| "
                f"PSNR: {self.train_meters['psnr'].value()[0]:.4f}|| "
                f"SSIM: {self.train_meters['ssim'].value()[0]:.4f}|| "
                f"Time: {utility.time_since(self.start_time)}|| "
                f"LR: {self.optimizer.param_groups[0]['lr']:.2e}||\n"
                f"=========================="
            )
            print(f"|> Best Avg PSNR: {self.best_avg_psnr:.4f}")
            if epoch_num % self.args.test_epochs == 0:
                torch.cuda.empty_cache()
                avg_rmse = self.test()
                if isinstance(
                    self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau
                ):
                    self.scheduler.step(avg_rmse)

    def test_model(self, attr):
        self.model.eval()
        test_loader = get_dataloader(self.args, attr).data_loader
        sum_time, rmse_list, psnr_list, ssim_list, name_list = 0, [], [], [], []
        rmse_meter = tnt.meter.AverageValueMeter()
        psnr_meter = tnt.meter.AverageValueMeter()
        ssim_meter = tnt.meter.AverageValueMeter()

        start, end = torch.cuda.Event(True), torch.cuda.Event(True)
        if self.args.save_val_images:
            test_epoch_dir = os.path.join(
                self.test_vis_dir, f"epoch_{self.epoch_num}", attr
            )
            os.makedirs(test_epoch_dir, exist_ok=True)

        with torch.no_grad():
            for batch_idx, sample in enumerate(tqdm.tqdm(test_loader)):
                # if batch_idx >= 10:
                #     break
                gt_img, ldr_img, min_val, max_val, name = (
                    sample["hdr_img"].to(self.device),
                    sample["ldr_img"].to(self.device),
                    sample["min_value"].to(self.device),
                    sample["max_value"].to(self.device),
                    sample["name"],
                )
                start.record()
                out = self.model(x=ldr_img)
                end.record()
                torch.cuda.synchronize()
                sum_time += start.elapsed_time(end)

                rmse = utility.root_mean_sqrt_error(out, gt_img)
                psnr = utility.batch_psnr(
                    utility.hdr_to_pu(out),
                    utility.hdr_to_pu(gt_img),
                    data_range=1.0,
                )
                ssim = utility.calculate_ssim(
                    utility.hdr_to_pu(out), utility.hdr_to_pu(gt_img)
                )
                rmse_list.append(rmse)
                psnr_list.append(psnr)
                ssim_list.append(ssim)
                rmse_meter.add(rmse)
                psnr_meter.add(psnr)
                ssim_meter.add(ssim)
                name_list.append(name)
                if self.args.save_val_images:
                    prefix = f"test_{attr}_epoch{self.epoch_num}"
                    input_tone = ldr_img  # utility.range_compressor_cuda(ldr_img)
                    gt_tone = utility.range_compressor_cuda(gt_img)
                    out_tone = utility.range_compressor_cuda(out)
                    utility.save_visualization(
                        input_tone,
                        out_tone,
                        gt_tone,
                        min_val,
                        max_val,
                        batch_idx,
                        prefix,
                        test_epoch_dir,
                    )
            # return meter.value()[0], round(sum_time / 1000, 5), rmse_list, name_list
            return (
                rmse_meter.value()[0],
                psnr_meter.value()[0],
                ssim_meter.value()[0],
                rmse_list,
                psnr_list,
                ssim_list,
                name_list,
                round(sum_time / 1000, 5),
            )

    def test(self):
        print("=" * 50)
        print("|> Testing model...")
        print("=" * 50)
        test_names = []
        test_rmses = []
        test_psnrs = []
        test_ssims = []
        test_times = []

        all_sample_rmses = []
        all_sample_psnrs = []
        all_sample_ssims = []
        all_sample_names = []
        all_sample_times = []

        # Run through each test split and collect both mean and sample-level errors
        with torch.no_grad():
            for test_name in self.args.test_set.split("+"):
                mul_ratio = 1
                if test_name == "test" and self.args.dataset_name == "AIM":
                    mul_ratio = 1
                (
                    avg_rmse,
                    avg_psnr,
                    avg_ssim,
                    sample_rmses,
                    sample_psnrs,
                    sample_ssims,
                    name_list,
                    time_list,
                ) = self.test_model(attr=test_name)
                test_names.append(test_name)
                test_rmses.append(round(avg_rmse, 4))

                test_psnrs.append(round(avg_psnr, 4))
                test_ssims.append(round(avg_ssim, 4))
                test_times.append(round(time_list, 4))

                all_sample_rmses.extend(sample_rmses)
                all_sample_names.extend(name_list)
                all_sample_times.extend([time_list] * len(name_list))
                all_sample_psnrs.extend(sample_psnrs)
                all_sample_ssims.extend(sample_ssims)

            # Compute overall average RMSE
            avg_rmse = sum(test_rmses) / len(test_rmses)
            avg_psnr = sum(test_psnrs) / len(test_psnrs)
            avg_ssim = sum(test_ssims) / len(test_ssims)
            avg_time = sum(test_times) / len(test_times)

        # Save best model
        if avg_psnr > self.best_avg_psnr:
            self.best_avg_psnr = avg_psnr
            state = dict(
                epoch=self.epoch_num,
                step=self.step,
                model_state_dict=self.model.state_dict(),
                optimizer_state_dict=self.optimizer.state_dict(),
                scheduler_state_dict=self.scheduler.state_dict(),
                best_avg_psnr=self.best_avg_psnr,
            )
            torch.save(state, os.path.join(self.checkpoint_dir, f"best.pth"))
            print("=" * 50)
            print(f"|> Saved best model (PSNR={avg_psnr:.4f})")
            print("=" * 50)

        # Always save a regular checkpoint
        torch.save(
            dict(
                epoch=self.epoch_num,
                step=self.step,
                model_state_dict=self.model.state_dict(),
                optimizer_state_dict=self.optimizer.state_dict(),
                scheduler_state_dict=self.scheduler.state_dict(),
                best_avg_psnr=self.best_avg_psnr,
            ),
            os.path.join(self.checkpoint_dir, "last.pth"),
        )

        # Print table of per-split averages
        # table = PrettyTable(test_names)
        # table.add_row(test_psnrs)
        # print(table)

        table = PrettyTable()
        # first column is the metric name, then one column per split
        table.field_names = ["Metric"] + test_names

        # add each metric as its own row
        table.add_row(["RMSE"] + test_rmses)
        table.add_row(["PSNR"] + test_psnrs)
        table.add_row(["SSIM"] + test_ssims)
        table.add_row(["Time (s)"] + test_times)

        print(table)

        bins = np.arange(0, 55, 5)  # 10-50 dB in steps of 5 dB
        psnr_array = np.array(all_sample_psnrs, dtype=np.float32)

        hist, edges = np.histogram(psnr_array, bins=bins)
        max_count = hist.max() if hist.max() > 0 else 1
        max_width = 50

        print("=" * 50)
        print("|> PSNR distribution (per-sample):")
        for low, high, count in zip(edges[:-1], edges[1:], hist):
            bar_len = int(count / max_count * max_width)
            bar = "#" * bar_len
            print(f"{low:>3.0f}-{high:<3.0f} | {count:>4d} | {bar}")

        with open(os.path.join(self.checkpoint_dir, f"psnr.txt"), "w") as f:
            for name, rmse in zip(all_sample_names, all_sample_psnrs):
                f.write(f"{name}: {rmse:.4f}\n")

        return avg_rmse

import glob
import os

import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


def detele_iccfile(image_path):
    img = Image.open(image_path)
    img.info.pop('icc_profile', None)
    img.save(image_path)


list_of_all_path = glob.glob('/home/jaemu/Codespace/dataset/Middlebury/*.[pP][nN][gG]')

rgb_count = 0
gt_count = 0

for path in list_of_all_path:
    detele_iccfile(path)


for path in list_of_all_path:
    detele_iccfile(path)
    image_name = path.split('/')[-1]
    img = Image.open(path)
    img_float = np.array(img).astype(np.float32)
    if 'output_depth' in image_name:
        np.save(path.replace('output_depth.png', '_gt.npy'), img_float)
        gt_count += 1
    elif 'output_color' in image_name:
        img_float = img_float.transpose(2, 0, 1)
        np.save(path.replace('output_color.png', '_rgb.npy'), img_float)
        rgb_count += 1
    else:
        os.remove(path)
    

if rgb_count == gt_count:
    print('rgb count: {}, gt count: {}'.format(rgb_count, gt_count))
else:
    print('rgb count: {}, gt count: {}'.format(rgb_count, gt_count))
    raise ValueError('rgb and gt count are not same')

# https://ddokkddokk.tistory.com/21
import os

import h5py
import numpy as np

# data path
path_to_depth = "nyu_depth_v2_labeled.mat"

# read mat file
f = h5py.File(path_to_depth)

train_path = "/home/jaemu/Codespace/dataset/NYU/train"
test_path = "/home/jaemu/Codespace/dataset/NYU/test"

if not os.path.exists(train_path):
    os.makedirs(train_path)

if not os.path.exists(test_path):
    os.makedirs(test_path)

for i in range(f["images"].shape[0]):
    # read 0-th image. original format is [3 x 640 x 480], uint8
    img = f["images"][i]
    img = np.transpose(img, (0, 2, 1))

    # read corresponding depth (aligned to the image, in-painted) of size [640 x 480], float64
    depth = f["depths"][i]
    depth = depth.T

    # save image
    if i < 1000:
        np.save(f"{train_path}/{i}_rgb.npy", img)
        np.save(f"{train_path}/{i}_gt.npy", depth)
    else:
        np.save(f"{test_path}/{i}_rgb.npy", img)
        np.save(f"{test_path}/{i}_gt.npy", depth)


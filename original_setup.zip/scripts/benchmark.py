import time
from typing import Optional, Tuple

import torch
import torch.nn as nn

try:
    from thop import profile
except ImportError:
    print("THOP not installed, skipping profiling")

    def profile(model, inputs):
        return 0, sum(p.numel() for p in model.parameters() if p.requires_grad)


class Benchmarker:
    def __init__(self, device="cuda"):
        self.device = device

    def measure_time(self, model, inputs: torch.Tensor, num_runs: int = 10) -> float:
        if torch.cuda.is_available():
            torch.cuda.synchronize()

        # Warmup
        for _ in range(2):
            _ = model(inputs)

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        start_time = time.time()

        for _ in range(min(5, num_runs)):
            _ = model(inputs)

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        end_time = time.time()

        return (end_time - start_time) / min(5, num_runs)

    def measure_memory(self, model, inputs: torch.Tensor) -> float:
        if not torch.cuda.is_available():
            return 0

        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()

        with torch.no_grad():
            _ = model(inputs)

        memory_stats = torch.cuda.memory_stats()
        peak_bytes = memory_stats["allocated_bytes.all.peak"]
        return peak_bytes / (1024 * 1024)  # Convert to MB

    def measure_gflops(self, model: nn.Module, inputs: torch.Tensor) -> float:
        macs, _ = profile(model, inputs=(inputs,), verbose=False)
        # THOP returns MACs; 1 MAC ≈ 2 FLOPs (multiply+add)
        return macs * 2 / 1e9  # GFLOPs

    def param_count(self, model):
        return sum(p.numel() for p in model.parameters() if p.requires_grad)


def run_benchmark(model, input_configs, upscale_factor_list):
    # Test with different upsampling factors
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Use smaller test resolution to avoid OOM
    B = input_configs["batch_size"]
    Cr = input_configs["in_channels"]
    Cd = input_configs["out_channels"]
    H = input_configs["H"]
    W = input_configs["W"]
    levels = input_configs["num_pyramid"]

    rgb = torch.rand(B, Cr, H, W).to(device)

    for upscale_factor in upscale_factor_list:
        print(f"\n-------- Testing {upscale_factor}x upsampling --------")

        # Initialize the guided upsampler
        net = model(in_channels=Cr, out_channels=Cd, levels=levels).to(device)

        # Training mode test
        net.train()
        with torch.no_grad():
            outputs = net(rgb)
        print(f"Training mode output shapes: {[o.shape for o in outputs]}")
        print(
            f"Each output's min/max: {[o.min().item() for o in outputs]}, {[o.max().item() for o in outputs]}"
        )

        # Eval mode test
        net.eval()
        with torch.no_grad():
            output = net(rgb)
        print(f"Eval mode output shape: {output.shape}")
        print(f"Output min/max: {output.min().item()}, {output.max().item()}")

        # Benchmark
        benchmark = Benchmarker(device)
        with torch.no_grad():
            print(
                f"Time complexity: {benchmark.measure_time(net, rgb, num_runs=3):.6f} s per run"
            )
            print(f"Memory complexity: {benchmark.measure_memory(net, rgb):.2f} MB")
            print(f"Number of parameters: {benchmark.param_count(net):,}")
            print(f"GFLOPs: {benchmark.measure_gflops(net, rgb):.2f} GFLOPs")

        torch.cuda.empty_cache()

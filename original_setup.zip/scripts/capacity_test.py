import torch
import torch.nn as nn
import torch.nn.functional as F
from option import args
from torch.utils.data import DataLoader

from data import get_dataloader
from model.dtm import GuidedUpsampler


# --- simple RMSE helper ---
def compute_rmse(pred, gt):
    return torch.sqrt(((pred - gt) ** 2).mean()).item()


def overfit_one_sample(
    model: nn.Module,
    dataloader: DataLoader,
    device: torch.device = None,
    lr: float = 1e-3,
    iters: int = 5000,
    log_interval: int = 100,
):
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device).train()

    # grab one batch
    sample = next(iter(dataloader))
    lr_img = sample["lr_img"].to(device)  # [1, 1, h, w]
    gt_img = sample["gt_img"].to(device)  # [1, 1, H, W]
    rgb_img = sample["rgb_img"].to(device)  # [1, 3, H, W]
    scale = gt_img.shape[-1] // lr_img.shape[-1]  # e.g. 4,8,16

    # pre‐upsample low‐res depth
    lr_up = F.interpolate(
        lr_img, scale_factor=scale, mode="bilinear", align_corners=False
    )

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.L1Loss()

    for it in range(1, iters + 1):
        optimizer.zero_grad()
        # forward
        out = model(
            lr_up=lr_up, rgb=rgb_img
        ) 
        loss = loss_fn(out[-1], gt_img)
        loss.backward()
        optimizer.step()

        if it % log_interval == 0 or it == 1:
            rmse = compute_rmse(out[-1], gt_img)
            print(f"[Iter {it:4d}/{iters}] L1={loss.item():.4e}  RMSE={rmse:.4e}")

    print("-> Final overfit RMSE:", compute_rmse(out[-1], gt_img))


if __name__ == "__main__":
    # build single‐sample loader
    train_loader = get_dataloader(args=args, attr="train").loader_train
    overfit_one_sample(
        model=GuidedUpsampler(base=32, levels=4),
        dataloader=train_loader,
        lr=1e-3,
        iters=2000,
        log_interval=100,
    )

import cv2
import matplotlib.pyplot as plt
import numpy as np

depth1 = np.load("/home/jaemu/Codespace/dataset/Lu/RGBD_01_gt.npy")
depth2 = np.load("/home/jaemu/Codespace/dataset/test_data/Lu/gt/1.npy")

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(depth1, cmap='gray')
plt.title("Original Depth")
plt.axis('off')
plt.subplot(1, 2, 2)
plt.imshow(depth2, cmap='gray')
plt.title("Upsampled Depth")
plt.axis('off')
plt.show()

print(np.max(depth1))
print(np.min(depth1))
print(np.max(depth2))
print(np.min(depth2))
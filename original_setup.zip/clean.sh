# find "in_current_directories" -what_type d -name_of_the_file "exact_name" -prune_operation -execution_op rm -rf {} +
find . -type d -name "__pycache__" -prune -exec rm -rf {} +

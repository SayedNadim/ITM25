import argparse
import os
import warnings

warnings.filterwarnings("ignore")

import cv2
import torch

cv2.setNumThreads(1)
cv2.ocl.setUseOpenCL(False)
torch.set_num_threads(8)


from prettytable import PrettyTable

import loss
import utility
from data import get_dataloader
from lr_scheduler import get_scheduler
from model import net
from Trainer import Trainer


def parse_args():
    parser = argparse.ArgumentParser(
        description="P2G2Net: Guided Depth Super-Resolution"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/base.yaml",
        help="Path to YAML configuration file.",
    )
    parser.add_argument(
        "--file_name", type=str, default="", help="Suffix for checkpoint and logs."
    )
    parser.add_argument(
        "--scheduler",
        type=str,
        default="CosineAnnealing",
        help="Learning rate scheduler to use.",
    )
    args_mod = parser.parse_args()
    # load base config
    args = utility.read_yaml(args_mod.config)
    # filename check
    if len(args.file_name) == 0:
        args.file_name = args.model_name
    # override scale, file_name, scheduler

    if args_mod.file_name:
        args.file_name = f"{args.model_name}_{args_mod.file_name}"
    if args_mod.scheduler != args.scheduler:
        args.scheduler = args_mod.scheduler
    if args.scheduler == "MultiStepLR":
        args.lr_decay_epochs = [int(num) for num in args.lr_decay_epochs.split("_")]
    return args


def main():
    # parse arguments
    args = parse_args()
    table = PrettyTable(["Key", "Value"])
    for k, v in args.items():
        if k == "file_name" or k == "data_dict":
            continue
        table.add_row([k, v])
        table.add_divider()
    print("|> Configuration:")
    print(table)
    print("=" * 50)
    utility.init_state()
    checkpoint_dir = utility.make_checkpoint_dir(args.file_name)

    # device setup
    device = torch.device("cpu" if args.cpu else "cuda")

    # model, loss, optimizer, scheduler
    model = net(
        in_channels=args.in_channels,
        out_channels=args.out_channels,
        base=args.base,
        levels=args.num_pyramid,
    ).to(device)

    if not args.cpu and args.num_gpus > 1:
        model = torch.nn.DataParallel(model, device_ids=list(range(args.num_gpus)))

    criterion = loss.Loss()
    optimizer = utility.make_optimizer(args, model)
    loader_train = get_dataloader(args=args, attr="train").loader_train
    scheduler = get_scheduler(optimizer, n_iter_per_epoch=len(loader_train), args=args)

    # optional checkpoint resume
    epoch_num = 0
    step = 0
    best_avg_psnr = -1e10
    if args.pretrained:
        ckpt_path = os.path.join(checkpoint_dir, f"best.pth")
        if os.path.exists(ckpt_path):
            print(f"|> Loading checkpoint: {ckpt_path}")
            ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
            model.load_state_dict(ckpt["model_state_dict"], strict=True)
            # optimizer.load_state_dict(ckpt["optimizer_state_dict"])
            # scheduler.load_state_dict(ckpt["scheduler_state_dict"])
            epoch_num = ckpt.get("epoch", 0) + 1
            step = ckpt.get("step", 0)
            best_avg_psnr = ckpt.get("best_avg_psnr", best_avg_psnr)
            print(f"|> Resumed from epoch {epoch_num}, step {step}")
            print(f"|> Best average PSNR: {best_avg_psnr:.4f}")
        else:
            print("|> No checkpoint found, starting from scratch.")

    # launch training
    trainer = Trainer(
        args=args,
        my_model=model,
        my_loss=criterion,
        checkpoint_dir=checkpoint_dir,
        device=device,
        optimizer=optimizer,
        scheduler=scheduler,
        epoch_num=epoch_num,
        step=step,
        best_avg_psnr=best_avg_psnr,
    )
    trainer.train()


if __name__ == "__main__":
    main()

# # # from __future__ import annotations

# # # import math
# # # from typing import List

# # # import kornia.color as kc
# # # import torch
# # # import torch.nn as nn
# # # import torch.nn.functional as F
# # # import torchvision
# # # from torchmetrics.image import StructuralSimilarityIndexMeasure

# # # # -----------------------------------------------------------------------------
# # # # Constants --------------------------------------------------------------------
# # # # -----------------------------------------------------------------------------
# # # MAX_HDR: float = 1.0  # cd/m^2
# # # MU: float = 5000.0  # MU-law parameter


# # # def range_compressor_cuda(hdr, MU: float = MU, max_hdr: float = MAX_HDR):
# # #     x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr  # normalise first
# # #     return torch.log1p(MU * x) / math.log1p(MU)


# # # def srgb_to_linear(srgb):
# # #     return torch.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)


# # # def linear_to_srgb(lin):
# # #     """Inverse of :pyfunc:`srgb_to_linear`. Input expected in [0,1]."""
# # #     a = 0.0031308
# # #     return torch.where(lin <= a, lin * 12.92, 1.055 * lin.pow(1 / 2.4) - 0.055)


# # # def tonemap(hdr):
# # #     """Wrapper used throughout the file."""
# # #     return range_compressor_cuda(hdr, MU, MAX_HDR)


# # # class VGGPerceptualLoss(nn.Module):
# # #     """L1 perceptual distance on VGG16 feature maps."""

# # #     def __init__(self, resize: bool = True) -> None:
# # #         super().__init__()
# # #         vgg = torchvision.models.vgg16(pretrained=True).features.eval()
# # #         for p in vgg.parameters():
# # #             p.requires_grad = False

# # #         # relu1_2, relu2_2, relu3_3, relu4_3
# # #         self.blocks = nn.ModuleList([vgg[:4], vgg[4:9], vgg[9:16], vgg[16:23]])
# # #         self.resize = resize
# # #         self.register_buffer(
# # #             "mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
# # #         )
# # #         self.register_buffer(
# # #             "std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
# # #         )

# # #     def forward(self, inp, tgt, layers: List[int] | None = None):  # noqa: N802
# # #         if layers is None:
# # #             layers = [0, 1, 2, 3]

# # #         if inp.shape[1] != 3:
# # #             inp = inp.repeat(1, 3, 1, 1)
# # #             tgt = tgt.repeat(1, 3, 1, 1)

# # #         inp = (inp - self.mean) / self.std
# # #         tgt = (tgt - self.mean) / self.std

# # #         if self.resize:
# # #             inp = F.interpolate(inp, (224, 224), mode="bilinear", align_corners=False)
# # #             tgt = F.interpolate(tgt, (224, 224), mode="bilinear", align_corners=False)

# # #         loss = 0.0
# # #         x, y = inp, tgt
# # #         for i, block in enumerate(self.blocks):
# # #             x, y = block(x), block(y)
# # #             if i in layers:
# # #                 loss += F.l1_loss(x, y)
# # #         return loss


# # # class L1MuLoss(nn.Module):
# # #     def __init__(self, MU: float = MU, max_hdr: float = MAX_HDR):
# # #         super().__init__()
# # #         self.MU = MU
# # #         self.max_hdr = max_hdr

# # #     def forward(self, inp, tgt):
# # #         tm_inp = range_compressor_cuda(inp, self.MU, self.max_hdr)
# # #         tm_tgt = range_compressor_cuda(tgt, self.MU, self.max_hdr)
# # #         return F.l1_loss(tm_inp, tm_tgt)


# # # # -----------------------------------------------------------------------------
# # # # Composite loss ---------------------------------------------------------------
# # # # -----------------------------------------------------------------------------


# # # class Loss(nn.Module):
# # #     def __init__(
# # #         self,
# # #         alpha_perc: float = 0.01,
# # #         beta_over: float = 0.5,
# # #         beta_under: float = 0.5,
# # #         gamma_ssim: float = 0.1,
# # #         lambda_linear: float = 0.1,
# # #         tau_low: float = 0.2,
# # #         tau_high: float = 0.8,
# # #         exp_alpha: float = 10.0,
# # #     ) -> None:
# # #         super().__init__()
# # #         self.recon = L1MuLoss()
# # #         self.perc = VGGPerceptualLoss(resize=False)
# # #         self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0)

# # #         self.alpha_perc = alpha_perc
# # #         self.beta_o = beta_over
# # #         self.beta_u = beta_under
# # #         self.gamma_ssim = gamma_ssim
# # #         self.lambda_linear = lambda_linear

# # #         self.tau_low = tau_low
# # #         self.tau_high = tau_high
# # #         self.exp_alpha = exp_alpha

# # #     def _exp_masks(self, ldr):
# # #         avg = ldr.mean(1, keepdim=True)  # luminance proxy (0-1)
# # #         under = torch.sigmoid(self.exp_alpha * (self.tau_low - avg))
# # #         over = torch.sigmoid(self.exp_alpha * (avg - self.tau_high))
# # #         return under, over

# # #     @staticmethod
# # #     def _mask_l1(mask, pred, gt):
# # #         return (mask * (pred - gt).abs()).mean()

# # #     def forward(self, pred_list, gt, ldr):
# # #         self.perc.to(gt.device)
# # #         self.ssim.to(gt.device)
# # #         # unpack
# # #         lin_out, *hdr_stages = pred_list
# # #         final = hdr_stages[-1]

# # #         # -- core losses ------------------------------------------------
# # #         L_recon = torch.stack([self.recon(p, gt) for p in hdr_stages]).mean()

# # #         final_tm = tonemap(final)
# # #         gt_tm = tonemap(gt)
# # #         L_perc = self.perc(final_tm, gt_tm)
# # #         L_ssim = 1.0 - self.ssim(final_tm, gt_tm)

# # #         # linear supervision (full range)
# # #         L_linear = F.l1_loss(lin_out, gt)

# # #         # exposure-aware penalties
# # #         under, over = self._exp_masks(ldr)
# # #         L_under = torch.stack([self._mask_l1(under, p, gt) for p in hdr_stages]).mean()
# # #         L_over = torch.stack([self._mask_l1(over, p, gt) for p in hdr_stages]).mean()

# # #         # total -----------------------------------------------------------
# # #         loss = (
# # #             L_recon
# # #             + self.alpha_perc * L_perc
# # #             + self.beta_o * L_over
# # #             + self.beta_u * L_under
# # #             + self.gamma_ssim * L_ssim
# # #             + self.lambda_linear * L_linear
# # #         )

# # #         return {
# # #             "loss": loss,
# # #             "recon": L_recon,
# # #             "perceptual": L_perc,
# # #             "ssim": L_ssim,
# # #             "linear": L_linear,
# # #             "over": L_over,
# # #             "under": L_under,
# # #         }


# # from __future__ import annotations

# # import math
# # from typing import List

# # import torch
# # import torch.nn as nn
# # import torch.nn.functional as F
# # import torchvision
# # from torchmetrics.image import StructuralSimilarityIndexMeasure

# # __all__ = [
# #     "srgb_to_linear",
# #     "linear_to_srgb",
# #     "range_compress",
# #     "VGGPerceptualLoss",
# #     "L1MuLoss",
# #     "Loss",
# # ]

# # # -----------------------------------------------------------------------------
# # # Constants & colour helpers
# # # -----------------------------------------------------------------------------
# # MAX_HDR: float = 1.0  # scene-referred peak after HDR normalisation
# # MU: float = 5_000.0  # MU-law parameter


# # def srgb_to_linear(srgb):
# #     return torch.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)


# # def linear_to_srgb(lin):
# #     a = 0.0031308
# #     return torch.where(lin <= a, lin * 12.92, 1.055 * lin.pow(1 / 2.4) - 0.055)


# # def range_compress(
# #     hdr, MU: float = MU, max_hdr: float = MAX_HDR
# # ):
# #     x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr  # normalise first
# #     return torch.log1p(MU * x) / math.log1p(MU)


# # # -----------------------------------------------------------------------------
# # # Component losses
# # # -----------------------------------------------------------------------------
# # class VGGPerceptualLoss(nn.Module):
# #     """L1 perceptual distance on selected VGG16 feature maps."""

# #     def __init__(self, resize: bool = True):
# #         super().__init__()
# #         vgg = torchvision.models.vgg16(pretrained=True).features.eval()
# #         for p in vgg.parameters():
# #             p.requires_grad = False
# #         # relu1_2, relu2_2, relu3_3, relu4_3
# #         self.blocks = nn.ModuleList([vgg[:4], vgg[4:9], vgg[9:16], vgg[16:23]])
# #         self.resize = resize
# #         self.register_buffer(
# #             "mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
# #         )
# #         self.register_buffer(
# #             "std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
# #         )

# #     def forward(
# #         self, inp, tgt, layers: List[int] | None = None
# #     ):  # noqa: N802
# #         if layers is None:
# #             layers = [0, 1, 2, 3]
# #         if inp.shape[1] != 3:
# #             inp = inp.repeat(1, 3, 1, 1)
# #             tgt = tgt.repeat(1, 3, 1, 1)
# #         inp = (inp - self.mean) / self.std
# #         tgt = (tgt - self.mean) / self.std
# #         if self.resize:
# #             inp = F.interpolate(inp, 224, mode="bilinear", align_corners=False)
# #             tgt = F.interpolate(tgt, 224, mode="bilinear", align_corners=False)
# #         loss = 0.0
# #         x, y = inp, tgt
# #         for i, block in enumerate(self.blocks):
# #             x, y = block(x), block(y)
# #             if i in layers:
# #                 loss = loss + F.l1_loss(x, y)
# #         return loss


# # class L1MuLoss(nn.Module):
# #     """L1 distance in MU-law-compressed domain."""

# #     def __init__(self, MU: float = MU, max_hdr: float = MAX_HDR):
# #         super().__init__()
# #         self.MU, self.max_hdr = MU, max_hdr

# #     def forward(self, inp, tgt):  # noqa: N802
# #         return F.l1_loss(
# #             range_compress(inp, self.MU, self.max_hdr),
# #             range_compress(tgt, self.MU, self.max_hdr),
# #         )


# # # -----------------------------------------------------------------------------
# # # Composite Loss
# # # -----------------------------------------------------------------------------
# # class Loss(nn.Module):
# #     """Composite HDR reconstruction loss with noise-aware de-quant term."""

# #     def __init__(
# #         self,
# #         alpha_perc: float = 0.01,
# #         beta_over: float = 0.5,
# #         beta_under: float = 0.5,
# #         gamma_ssim: float = 0.1,
# #         lambda_linear: float = 0.1,
# #         tau_low: float = 0.05,
# #         tau_high: float = 0.5,
# #         exp_alpha: float = 10.0,
# #         denoise_alpha: float = 0.5,
# #         charbonnier_eps: float = 1e-3,
# #     ) -> None:
# #         super().__init__()
# #         self.recon = L1MuLoss()
# #         self.perc = VGGPerceptualLoss(resize=False)
# #         self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0)

# #         # scalars
# #         self.alpha_perc = alpha_perc
# #         self.beta_o = beta_over
# #         self.beta_u = beta_under
# #         self.gamma_ssim = gamma_ssim
# #         self.lambda_linear = lambda_linear

# #         # exposure mask params tuned for *linear* input
# #         self.tau_low = tau_low
# #         self.tau_high = tau_high
# #         self.exp_alpha = exp_alpha

# #         self.denoise_alpha = denoise_alpha

# #         self.char_eps = charbonnier_eps

# #     # ------------------------------------------------------------------ helpers
# #     def _exp_masks(self, ldr):
# #         luma = ldr.mean(1, keepdim=True)
# #         under = torch.sigmoid(self.exp_alpha * (self.tau_low - luma))
# #         over = torch.sigmoid(self.exp_alpha * (luma - self.tau_high))
# #         return under, over

# #     def _charbonnier(self, pred, tgt):
# #         return torch.sqrt((pred - tgt).pow(2) + self.char_eps**2).mean()

# #     def _masked_l1(self, mask, pred, tgt):
# #         return (mask * (pred - tgt).abs()).mean()

# #     # ------------------------------------------------------------------ forward
# #     def forward(
# #         self, pred_list, gt, ldr
# #     ):
# #         self.perc.to(gt.device)
# #         self.ssim.to(gt.device)
# #         x_denoised, x_deq, *hdrs = pred_list
# #         hdr_final = hdrs[-1]

# #         # denoised input
# #         L_denoised = F.l1_loss(x_denoised, gt)

# #         # MU-law reconstruction across HDR stages
# #         L_recon = torch.stack([self.recon(h, gt) for h in hdrs]).mean()

# #         # perceptual + SSIM in tonemapped space
# #         hdr_tm = range_compress(hdr_final)
# #         gt_tm = range_compress(gt)
# #         L_perc = self.perc(hdr_tm, gt_tm)
# #         L_ssim = 1.0 - self.ssim(hdr_tm.clamp(0, 1), gt_tm.clamp(0, 1))

# #         # noise-aware supervision for the de-quant output (vs *clean* HDR)
# #         L_linear = F.l1_loss(x_deq, gt)

# #         # exposure-aware masked errors
# #         under_m, over_m = self._exp_masks(srgb_to_linear(ldr))
# #         L_under = torch.stack([self._masked_l1(under_m, h, gt) for h in hdrs]).mean()
# #         L_over = torch.stack([self._masked_l1(over_m, h, gt) for h in hdrs]).mean()

# #         loss = (
# #             L_recon
# #             + self.alpha_perc * L_perc
# #             + self.beta_o * L_over
# #             + self.beta_u * L_under
# #             + self.gamma_ssim * L_ssim
# #             + self.lambda_linear * L_linear
# #             + self.denoise_alpha * L_denoised
# #         )

# #         return {
# #             "loss": loss,
# #             "recon": L_recon.detach(),
# #             "perceptual": L_perc.detach(),
# #             "ssim": L_ssim.detach(),
# #             "linear": L_linear.detach(),
# #             "over": L_over.detach(),
# #             "under": L_under.detach(),
# #             "denoised": L_denoised.detach(),
# #         }


# from __future__ import annotations

# import math
# from typing import List

# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# import torchvision
# from torchmetrics.image import StructuralSimilarityIndexMeasure

# # -----------------------------------------------------------------------------
# # Constants & helpers
# # -----------------------------------------------------------------------------
# MAX_HDR: float = 1.0  # scene‑referred peak after HDR normalisation
# MU: float = 5_000.0   # µ‑law parameter for range compression


# # -------------------------- tone‑mapping helpers -----------------------------

# def range_compress(hdr, MU: float = MU, max_hdr: float = MAX_HDR):
#     """µ-law range compressor used during training-time supervision."""
#     x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr
#     return torch.log1p(MU * x) / math.log1p(MU)


# def hdr_to_pu(hdr, c: float = 10_000.0, max_hdr: float = MAX_HDR):
#     """Perceptual-Uniform (PU) encoding approximated by Mantiuk 2015 formula.

#     Y_pu = log10(1 + c · Y) / log10(1 + c)
#     Works channel-wise; input must be normalised to [0, max_hdr].
#     """
#     x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr
#     return torch.log10(1.0 + c * x) / math.log10(1.0 + c)


# # ------------------------------ colour loss ----------------------------------

# class LogChrominanceLoss3(nn.Module):
#     """Exposue-invariant colour consistency via three log-ratio channels."""

#     def __init__(self, eps: float = 1e-6) -> None:  # noqa: W605
#         super().__init__()
#         self.eps = eps

#     def forward(self, pred, tgt):  # noqa: N802
#         pred = pred.clamp(min=self.eps)
#         tgt = tgt.clamp(min=self.eps)

#         log_pred = torch.log(pred)
#         log_tgt = torch.log(tgt)

#         # R/G, G/B, B/R log‑ratios
#         c1_p = log_pred[:, 0] - log_pred[:, 1]
#         c1_t = log_tgt[:, 0] - log_tgt[:, 1]
#         c2_p = log_pred[:, 1] - log_pred[:, 2]
#         c2_t = log_tgt[:, 1] - log_tgt[:, 2]
#         c3_p = log_pred[:, 2] - log_pred[:, 0]
#         c3_t = log_tgt[:, 2] - log_tgt[:, 0]

#         return (F.l1_loss(c1_p, c1_t) + F.l1_loss(c2_p, c2_t) + F.l1_loss(c3_p, c3_t))


# # ------------------------------ perceptual L1 --------------------------------

# class VGGPerceptualLoss(nn.Module):
#     """L1 perceptual distance on selected VGG16 feature maps."""

#     def __init__(self, resize: bool = True):
#         super().__init__()
#         vgg = torchvision.models.vgg16(pretrained=True).features.eval()
#         for p in vgg.parameters():
#             p.requires_grad = False
#         # relu1_2, relu2_2, relu3_3, relu4_3
#         self.blocks = nn.ModuleList([vgg[:4], vgg[4:9], vgg[9:16], vgg[16:23]])
#         self.resize = resize
#         self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
#         self.register_buffer("std",  torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

#     def forward(self, inp, tgt, layers: List[int] | None = None):  # noqa: N802
#         if layers is None:
#             layers = [0, 1, 2, 3]
#         if inp.shape[1] != 3:
#             inp, tgt = inp.repeat(1, 3, 1, 1), tgt.repeat(1, 3, 1, 1)
#         inp = (inp - self.mean) / self.std
#         tgt = (tgt - self.mean) / self.std
#         if self.resize:
#             inp = F.interpolate(inp, 224, mode="bilinear", align_corners=False)
#             tgt = F.interpolate(tgt, 224, mode="bilinear", align_corners=False)
#         loss, x, y = 0.0, inp, tgt
#         for i, block in enumerate(self.blocks):
#             x, y = block(x), block(y)
#             if i in layers:
#                 loss = loss + F.l1_loss(x, y)
#         return loss


# class L1MuLoss(nn.Module):
#     """L1 distance in MU-law-compressed domain."""

#     def __init__(self, MU: float = MU, max_hdr: float = MAX_HDR):
#         super().__init__()
#         self.MU, self.max_hdr = MU, max_hdr

#     def forward(self, inp, tgt):  # noqa: N802
#         return F.l1_loss(range_compress(inp, self.MU, self.max_hdr), range_compress(tgt, self.MU, self.max_hdr))


# # -----------------------------------------------------------------------------
# # Composite loss with colour + PU‑SSIM
# # -----------------------------------------------------------------------------

# class Loss(nn.Module):
#     """Composite HDR loss with chrominance and PU-domain SSIM."""

#     def __init__(
#         self,
#         alpha_perc: float = 0.01,
#         beta_over: float = 0.5,
#         beta_under: float = 0.5,
#         gamma_ssim_pu: float = 0.1,
#         gamma_colour: float = 0.05,
#         lambda_linear: float = 0.1,
#         tau_low: float = 0.05,
#         tau_high: float = 0.5,
#         exp_alpha: float = 10.0,
#         denoise_alpha: float = 0.5,
#     ) -> None:
#         super().__init__()

#         # core terms
#         self.recon = L1MuLoss()
#         self.perc = VGGPerceptualLoss(resize=False)
#         self.ssim_pu = StructuralSimilarityIndexMeasure(data_range=1.0)
#         self.colour = LogChrominanceLoss3()

#         # scalar weights
#         self.alpha_perc = alpha_perc
#         self.beta_o = beta_over
#         self.beta_u = beta_under
#         self.gamma_ssim_pu = gamma_ssim_pu
#         self.gamma_colour = gamma_colour
#         self.lambda_linear = lambda_linear
#         self.denoise_alpha = denoise_alpha

#         # exposure mask params (linear domain)
#         self.tau_low = tau_low
#         self.tau_high = tau_high
#         self.exp_alpha = exp_alpha

#     # ---------------------------------------------------------------- helpers
#     def _exp_masks(self, ldr):  # ldr in linear domain
#         luma = ldr.mean(1, keepdim=True)
#         under = torch.sigmoid(self.exp_alpha * (self.tau_low - luma))
#         over = torch.sigmoid(self.exp_alpha * (luma - self.tau_high))
#         return under, over

#     def _masked_l1(self, mask, pred, tgt):
#         return (mask * (pred - tgt).abs()).mean()

#     # ---------------------------------------------------------------- forward
#     def forward(self, pred_list, gt, ldr):

#         self.perc.to(gt.device)
#         self.ssim_pu.to(gt.device)

#         x_denoised, x_deq, *hdrs = pred_list
#         hdr_final = hdrs[-1]

#         # --- base losses ----------------------------------------------------
#         L_denoised = F.l1_loss(x_denoised, gt)
#         L_recon = torch.stack([self.recon(h, gt) for h in hdrs]).mean()
#         L_colour = self.colour(hdr_final, gt)

#         # perceptual on tone‑mapped
#         hdr_tm, gt_tm = range_compress(hdr_final), range_compress(gt)
#         L_perc = self.perc(hdr_tm, gt_tm)

#         # PU‑domain SSIM
#         hdr_pu, gt_pu = hdr_to_pu(hdr_final), hdr_to_pu(gt)
#         L_ssim_pu = 1.0 - self.ssim_pu(hdr_pu.clamp(0, 1), gt_pu.clamp(0, 1))

#         # de‑quant supervision
#         L_linear = F.l1_loss(x_deq, gt)

#         # exposure‑aware errors
#         under_m, over_m = self._exp_masks(ldr)
#         L_under = torch.stack([self._masked_l1(under_m, h, gt) for h in hdrs]).mean()
#         L_over = torch.stack([self._masked_l1(over_m, h, gt) for h in hdrs]).mean()

#         # total --------------------------------------------------------------
#         loss = (
#             L_recon
#             + self.alpha_perc * L_perc
#             + self.beta_o * L_over
#             + self.beta_u * L_under
#             + self.gamma_ssim_pu * L_ssim_pu
#             + self.gamma_colour * L_colour
#             + self.lambda_linear * L_linear
#             + self.denoise_alpha * L_denoised
#         )

#         return {
#             "loss": loss,
#             "recon": L_recon.detach(),
#             "perceptual": L_perc.detach(),
#             "ssim_pu": L_ssim_pu.detach(),
#             "colour": L_colour.detach(),
#             "linear": L_linear.detach(),
#             "over": L_over.detach(),
#             "under": L_under.detach(),
#             "denoised": L_denoised.detach(),
#         }


from __future__ import annotations

import math
from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from torchmetrics.image import StructuralSimilarityIndexMeasure

# -----------------------------------------------------------------------------
# Constants & helpers
# -----------------------------------------------------------------------------
MAX_HDR: float = 1.0  # scene-referred peak after HDR normalization
MU: float = 5_000.0  # µ-law parameter for range compression


# -----------------------------------------------------------------------------
# Tone-mapping & PU helpers
# -----------------------------------------------------------------------------
def range_compress(hdr, MU: float = MU, max_hdr: float = MAX_HDR):
    x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr
    return torch.log1p(MU * x) / math.log1p(MU)


def hdr_to_pu(hdr, c: float = 10_000.0, max_hdr: float = MAX_HDR):
    x = torch.clamp(hdr, 0.0, max_hdr) / max_hdr
    return torch.log10(1.0 + c * x) / math.log10(1.0 + c)


# -----------------------------------------------------------------------------
# Perceptual and colour losses
# -----------------------------------------------------------------------------
# # ------------------------------ colour loss ----------------------------------


class LogChrominanceLoss3(nn.Module):
    """Exposue-invariant colour consistency via three log-ratio channels."""

    def __init__(self, eps: float = 1e-6) -> None:  # noqa: W605
        super().__init__()
        self.eps = eps

    def forward(self, pred, tgt):  # noqa: N802
        pred = pred.clamp(min=self.eps)
        tgt = tgt.clamp(min=self.eps)

        log_pred = torch.log(pred)
        log_tgt = torch.log(tgt)

        # R/G, G/B, B/R log‑ratios
        c1_p = log_pred[:, 0] - log_pred[:, 1]
        c1_t = log_tgt[:, 0] - log_tgt[:, 1]
        c2_p = log_pred[:, 1] - log_pred[:, 2]
        c2_t = log_tgt[:, 1] - log_tgt[:, 2]
        c3_p = log_pred[:, 2] - log_pred[:, 0]
        c3_t = log_tgt[:, 2] - log_tgt[:, 0]

        return F.l1_loss(c1_p, c1_t) + F.l1_loss(c2_p, c2_t) + F.l1_loss(c3_p, c3_t)


# ------------------------------ perceptual L1 --------------------------------


class VGGPerceptualLoss(nn.Module):
    """L1 perceptual distance on selected VGG16 feature maps."""

    def __init__(self, resize: bool = True):
        super().__init__()
        vgg = torchvision.models.vgg16(pretrained=True).features.eval()
        for p in vgg.parameters():
            p.requires_grad = False
        # relu1_2, relu2_2, relu3_3, relu4_3
        self.blocks = nn.ModuleList([vgg[:4], vgg[4:9], vgg[9:16], vgg[16:23]])
        self.resize = resize
        self.register_buffer(
            "mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        )
        self.register_buffer(
            "std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        )

    def forward(self, inp, tgt, layers: List[int] | None = None):  # noqa: N802
        if layers is None:
            layers = [0, 1, 2, 3]
        if inp.shape[1] != 3:
            inp, tgt = inp.repeat(1, 3, 1, 1), tgt.repeat(1, 3, 1, 1)
        inp = (inp - self.mean) / self.std
        tgt = (tgt - self.mean) / self.std
        if self.resize:
            inp = F.interpolate(inp, 224, mode="bilinear", align_corners=False)
            tgt = F.interpolate(tgt, 224, mode="bilinear", align_corners=False)
        loss, x, y = 0.0, inp, tgt
        for i, block in enumerate(self.blocks):
            x, y = block(x), block(y)
            if i in layers:
                loss = loss + F.l1_loss(x, y)
        return loss


class L1MuLoss(nn.Module):
    """L1 distance in MU-law-compressed domain."""

    def __init__(self, MU: float = MU, max_hdr: float = MAX_HDR):
        super().__init__()
        self.MU, self.max_hdr = MU, max_hdr

    def forward(self, inp, tgt):  # noqa: N802
        return F.l1_loss(
            range_compress(inp, self.MU, self.max_hdr),
            range_compress(tgt, self.MU, self.max_hdr),
        )


# -----------------------------------------------------------------------------
# Composite loss with Unified Patch Fidelity (UPF)
# -----------------------------------------------------------------------------
class Loss(nn.Module):
    def __init__(
        self,
        alpha_perc: float = 0.1, # 1, # 310E ,
        gamma_ssim_pu: float = 0.1, # 1, # 310E ,
        gamma_colour: float = 0.05, # 0.1, # 310E ,
        lambda_linear: float = 0.1,
        denoise_alpha: float = 0.1,
        upf_alpha: float = 0.1,
        gamma_tv: float = 0.1,
        # UPF hyperparams
        patch_size: int = 16, # 32, # 310E ,
        gamma_focal: float = 1.5,
        alpha_hist: float = 0.1,
        beta_smooth: float = 0.05,
        charbonnier_eps: float = 1e-3,
        hist_bins: int = 64,
        hist_sigma: float = 0.1,
        debug: bool = False,
    ) -> None:
        super().__init__()
        
        self.debug = debug
        # core terms
        self.perc = VGGPerceptualLoss(resize=False).cuda()
        self.ssim_pu = StructuralSimilarityIndexMeasure(data_range=1.0).cuda()
        self.colour = LogChrominanceLoss3()

        # scalar weights
        self.alpha_perc = alpha_perc
        self.gamma_ssim = gamma_ssim_pu
        self.gamma_colour = gamma_colour
        self.lambda_linear = lambda_linear
        self.denoise_alpha = denoise_alpha
        self.upf_alpha = upf_alpha
        self.gamma_tv = gamma_tv

        # UPF params
        self.patch_size = patch_size
        self.gamma_focal = gamma_focal
        self.alpha_hist = alpha_hist
        self.beta_smooth = beta_smooth
        self.charb_eps = charbonnier_eps
        self.hist_bins = hist_bins
        self.hist_sigma = hist_sigma

        # patch extractor
        self.unfold = nn.Unfold(kernel_size=patch_size, stride=patch_size)
        # histogram bin centers in log domain
        self.register_buffer(
            "bin_centers",
            torch.linspace(-math.log1p(MU), math.log1p(MU), hist_bins).view(
                1, hist_bins, 1, 1
            ),
        )


    def _compute_upf(self, pred, gt):
        # 1) focal Charbonnier on log-luminance
        eps = self.charb_eps
        pred = pred.clamp(min=eps)
        gt = gt.clamp(min=eps)
        lum_pred = pred.mean(1, keepdim=True)
        lum_gt = gt.mean(1, keepdim=True)
        log_pred = torch.log(lum_pred + eps)
        log_gt = torch.log(lum_gt + eps)
        e = log_pred - log_gt
        w_focal = e.abs().pow(self.gamma_focal)

        # extract patches
        patches_e = self.unfold(e)
        patches_w = self.unfold(w_focal)
        charb = torch.sqrt(patches_e.pow(2) + eps * eps)
        L_charb = (patches_w * charb).mean()

        # 2) global soft-histogram in log domain
        B, _, H, W = pred.shape
        bc = self.bin_centers.to(pred.device)
        a_pred = torch.exp(-(log_pred - bc).pow(2) / (2 * self.hist_sigma**2))
        a_pred = a_pred / (a_pred.sum(dim=1, keepdim=True) + 1e-6)
        H_pred = a_pred.mean(dim=[2, 3])
        a_gt = torch.exp(-(log_gt - bc).pow(2) / (2 * self.hist_sigma**2))
        a_gt = a_gt / (a_gt.sum(dim=1, keepdim=True) + 1e-6)
        H_gt = a_gt.mean(dim=[2, 3])
        L_hist = (H_pred - H_gt).pow(2).mean()

        # 3) edge-aware smoothness
        weight = self._lap_kernel(pred.device).repeat(3, 1, 1, 1)
        lap = F.conv2d(pred, weight=weight, padding=1, groups=3)
        # trust mask from LDR not needed since exposure loss removed
        L_smooth = lap.abs().mean()

        return L_charb + self.alpha_hist * L_hist + self.beta_smooth * L_smooth

    @staticmethod
    def _lap_kernel(device: torch.device):
        k = torch.tensor(
            [[[0, 1, 0], [1, -4, 1], [0, 1, 0]]], dtype=torch.float32, device=device
        )
        return k.unsqueeze(1)

    @staticmethod
    def _tv_loss(img: torch.Tensor) -> torch.Tensor:
        """Anisotropic TV (L1) on the raw HDR prediction."""
        diff_h = img[..., 1:] - img[..., :-1]
        diff_v = img[..., 1:, :] - img[..., :-1, :]
        return diff_h.abs().mean() + diff_v.abs().mean()

    def forward(self, pred_list, gt, ldr):
        x_denoised, x_deq, *hdrs = pred_list
        hdr_final = hdrs[-1]

        # core losses
        # L_denoised = F.l1_loss(
        #     range_compress(x_denoised, MU, MAX_HDR), range_compress(gt, MU, MAX_HDR)
        # )
        L_denoised = (
            (
                x_denoised
                - gt
                - F.avg_pool2d(x_denoised - gt, kernel_size=5, stride=1, padding=2)
            )
            .abs()
            .mean()
        )
        L_recon = 0
        for i, pred in enumerate(hdrs):
            # give progressively more weight to later stages
            weight = (i + 1) / len(hdrs)
            pred_compressed = range_compress(pred, MU, MAX_HDR)
            gt_compressed = range_compress(gt, MU, MAX_HDR)
            L_recon += weight * F.l1_loss(pred_compressed, gt_compressed)

        L_linear = F.l1_loss(hdr_final, gt)
        L_colour = self.colour(hdr_final, gt)

        # perceptual + SSIM in PU space
        hdr_pu, gt_pu = hdr_to_pu(hdr_final), hdr_to_pu(gt)
        hdr_tonemapped = range_compress(hdr_final)
        gt_tonemapped = range_compress(gt)
        L_perc = self.perc(hdr_tonemapped, gt_tonemapped)
        L_ssim_pu = 1.0 - self.ssim_pu(hdr_pu.clamp(0, 1), gt_pu.clamp(0, 1))

        # Unified Patch Fidelity loss
        L_upf = self._compute_upf(hdr_final, gt)

        # # total-variation
        L_tv = self._tv_loss(hdr_final)

        # total
        loss = (
            L_recon
            + self.alpha_perc * L_perc
            + self.gamma_ssim * L_ssim_pu
            + self.gamma_colour * L_colour
            + self.gamma_tv * L_tv
            + self.lambda_linear * L_linear
            + self.denoise_alpha * L_denoised
            + self.upf_alpha * L_upf
        )

        if self.debug:
            terms = [
                ("recon",    1.0,               L_recon),
                ("perc",     self.alpha_perc,   L_perc),
                ("ssim_pu",  self.gamma_ssim,   L_ssim_pu),
                ("colour",   self.gamma_colour, L_colour),
                ("tv",       self.gamma_tv,     L_tv),
                ("linear",   self.lambda_linear,L_linear),
                ("denoised", self.denoise_alpha,L_denoised),
                ("upf",      self.upf_alpha,    L_upf),
            ]


            print(f"{'idx':>3} | {'name':<9} | {'w':>6} | {'contrib':>10} | {'cumul':>10}")
            print("-"*45)

            cumul = 0.0
            for idx, (name, w, val) in enumerate(terms):
                contrib = (w * val).item()      # scalar
                cumul  += contrib
                print(f"{idx:>3} | {name:<9} | {w:6.3f} | {contrib:10.4f} | {cumul:10.4f}")

            print(f"\nTotal loss = {cumul:.4f}\n")



        return {
            "loss": loss,
            "recon": L_recon.detach(),
            "perceptual": L_perc.detach(),
            "ssim_pu": L_ssim_pu.detach(),
            "colour": L_colour.detach(),
            "tv": L_tv.detach(),  
            "linear": L_linear.detach(),
            "denoised": L_denoised.detach(),
            "upf": L_upf.detach(),
        }
